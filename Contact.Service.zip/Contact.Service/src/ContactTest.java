import org.junit.Test;
import static org.junit.Assert.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");

        contactService.addContact(contact);

        assertEquals(1, contactService.getAllContacts().size());
        assertEquals(contact, contactService.getContactByID("1234567890"));
    }

    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        contactService.deleteContact("1234567890");

        assertEquals(0, contactService.getAllContacts().size());
        assertNull(contactService.getContactByID("1234567890"));
    }

    @Test
    public void testUpdateContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        contactService.updateContact("1234567890", "firstName", "Jane");

        assertEquals("Jane", contactService.getContactByID("1234567890").getFirstName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateInvalidField() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        contactService.updateContact("1234567890", "invalidField", "New Value");
    }

    // Add more tests to cover different scenarios and edge cases
}
