/**
 * 
 */
/**
 * 
 */
module Contact.Service {
}