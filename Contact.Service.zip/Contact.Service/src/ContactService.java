import java.util.ArrayList;
import java.util.List;

public class ContactService {
    private List<Contact> contacts;

    public ContactService() {
        this.contacts = new ArrayList<>();
    }

    public void addContact(Contact contact) {
        // Check for duplicate contactID before adding
        if (contacts.stream().anyMatch(c -> c.getContactID().equals(contact.getContactID()))) {
            throw new IllegalArgumentException("Contact with the same ID already exists");
        }

        contacts.add(contact);
    }

    public void deleteContact(String contactID) {
        contacts.removeIf(contact -> contact.getContactID().equals(contactID));
    }

    public void updateContact(String contactID, String field, String value) {
        Contact contactToUpdate = contacts.stream()
                .filter(c -> c.getContactID().equals(contactID))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Contact not found"));

        switch (field) {
            case "firstName":
                contactToUpdate = new Contact(contactToUpdate.getContactID(), value, contactToUpdate.getLastName(), contactToUpdate.getPhone(), contactToUpdate.getAddress());
                break;
            case "lastName":
                contactToUpdate = new Contact(contactToUpdate.getContactID(), contactToUpdate.getFirstName(), value, contactToUpdate.getPhone(), contactToUpdate.getAddress());
                break;
            case "phone":
                contactToUpdate = new Contact(contactToUpdate.getContactID(), contactToUpdate.getFirstName(), contactToUpdate.getLastName(), value, contactToUpdate.getAddress());
                break;
            case "address":
                contactToUpdate = new Contact(contactToUpdate.getContactID(), contactToUpdate.getFirstName(), contactToUpdate.getLastName(), contactToUpdate.getPhone(), value);
                break;
            default:
                throw new IllegalArgumentException("Invalid field for updating contact");
        }

        contacts.removeIf(c -> c.getContactID().equals(contactID));
        contacts.add(contactToUpdate);
    }

    public List<Contact> getAllContacts() {
        return new ArrayList<>(contacts);
    }

    public Contact getContactByID(String contactID) {
        return contacts.stream()
                .filter(c -> c.getContactID().equals(contactID))
                .findFirst()
                .orElse(null);
    }
}
