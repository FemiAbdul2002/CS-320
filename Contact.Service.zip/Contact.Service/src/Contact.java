import java.util.Objects;

public class Contact {
    private String contactID;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactID, String firstName, String lastName, String phone, String address) {
        // Validate input according to requirements
        if (contactID == null || contactID.length() > 10 ||
            firstName == null || firstName.length() > 10 ||
            lastName == null || lastName.length() > 10 ||
            phone == null || phone.length() != 10 ||
            address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid contact information");
        }

        this.contactID = contactID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    public String getContactID() {
        return contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }
    
  	public void setFirstName(String firstName){
      this.firstName = firstName;
    }
  
    public void setLastName(String lastName){
      this.lastName = lastName;
    }
    public void phone(String phone){
      this.phone = phone;
    }
  	public void setaddress(String address){
      this.address = address;
    }

    
  @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Contact contact = (Contact) o;
        return contactID.equals(contact.contactID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(contactID);
    }
}